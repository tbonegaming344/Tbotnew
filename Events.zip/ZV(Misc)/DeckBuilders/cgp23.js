const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
} = require("discord.js");
const db = require("../../index.js");
const buildDeckEmbed = require("../../Utilities/buildDeckEmbed.js");
module.exports = {
  name: `cgp23`,
  aliases: [
    `cgp23decks`,
    `cgp23help`,
    `helpcgp23`,
    `cgpdecks`,
    `cgphelp`,
    `cgp`,
  ],
  category: `DeckBuilders`,
  run: async (client, message, args) => {
    const color = "Grey";
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("sunlord")
        .setEmoji("<:arrowbackremovebgpreview:1271448914733568133>")
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId("slord")
        .setEmoji("<:arrowright:1271446796207525898>")
        .setStyle(ButtonStyle.Primary)
    );
    const slord = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("helpcgp")
        .setEmoji("<:arrowbackremovebgpreview:1271448914733568133>")
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId("help")
        .setEmoji("<:arrowright:1271446796207525898>")
        .setStyle(ButtonStyle.Primary)
    );
    const decks = ["sunlord"];
    const toBuildString = decks
      .map((d) => `\n<@1043528908148052089> **${d}**`)
      .join("");
    const [rows] = await db.query(
      `select * from ntdecks where creator like '%CGP23%'`
    );
    if (!rows || rows.length === 0) {
      return message.channel.send("No CGP decks found in the database.");
    }

    // normalize rows and key properties (added normalization fields)
    const normalized = rows.map((r) => {
      const rawType = (r.type || "").toString();
      const rawArch = (r.archetype || "").toString();
      const normalize = (s) => s.toLowerCase().replace(/[^a-z0-9]/g, ""); // remove spaces/punctuation
      return {
        id: r.deckID ?? null,
        name: r.name ?? r.deckID ?? "Unnamed",
        type: rawType,
        archetype: rawArch,
        cost: r.cost ?? r.deckcost ?? "",
        typeNorm: normalize(rawType),
        archetypeNorm: normalize(rawArch),
        description: r.description ?? "",
        image: r.image ?? null,
        creator: r.creator ?? "",
        raw: r,
      };
    });
    const user = await client.users.fetch("1044624858933383209");
    const cgp = new EmbedBuilder()
      .setTitle(`${user.displayName} Decks`)
      .setDescription(
        `My commands for decks made by ${user.displayName} are ${toBuildString}`
      )
      .setFooter({
        text: `To find out more about the Decks Made By ${user.displayName} please use the commands listed above or click on the buttons below!
Note: ${user.displayName} has ${decks.length} total decks in Tbot`,
      })
      .setThumbnail(user.displayAvatarURL())
      .setColor(color);
    const sunlord = buildDeckEmbed(normalized[0], color);
    const m = await message.channel.send({ embeds: [cgp], components: [row] });
    const iFilter = (i) => i.user.id === message.author.id;
    const collector = m.createMessageComponentCollector({ filter: iFilter });
    collector.on("collect", async (i) => {
      if (i.customId == "slord" || i.customId == "sunlord") {
        await i.update({ embeds: [sunlord], components: [slord] });
      } else if (i.customId == "helpcgp" || i.customId == "help") {
        await i.update({ embeds: [cgp], components: [row] });
      }
    });
  },
};
